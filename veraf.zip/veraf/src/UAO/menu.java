/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UAO;

/**
 *
 * @author Samy
 */
public class menu {

    public void menu_principal() {
        System.out.println("                                            ");
        System.out.println("                                            ");
        System.out.println("************** UNIVERSIDAD AUTONOMA DE OCCIDENTE **************");
        System.out.println("                  Algoritmos Criptograficos ");
        System.out.println("                                            ");
        System.out.println("                                            ");
        
        System.out.println("Sintaxis: java -jar veraf.jar <algoritmo>");
        System.out.println("                                            ");
        System.out.println("-af         :Algoritmo de Sustitucion monoalfabetica AFIN.");
        System.out.println("-ve         :Algoritmo de Sustitucion polialfabetica de VERNAM.");
        System.out.println("                                            ");
        System.out.println("                                            ");
        System.out.println("                                            ");
        System.out.println("                                            ");
        System.out.println("Especializacion en Seguridad informatica, 2019 - 2");
        System.out.println("Introduccion a la Criptografia.");
        System.out.println("Profesor: Msc.Siler Amador Donado.");
        System.out.println("                                            ");
        System.out.println("Elaborado por:  Wilmer Coral:       jwcl61@hotmail.com");
        System.out.println("                Osvaldo Jimenez:    shukko55@hotmail.com");
        System.out.println("                                            ");
        System.out.println("El codigo fuente,los archivos de texto utilizados y las claves de cada");
        System.out.println("algoritmo se encuentra en el siguiente repositorio:");
        System.out.println("                                            ");
        System.out.println("https://mega.nz/#F!rdpxQIwK!HdRw6uKH8Ibga4b9Oxh8tQ");
        System.out.println("");
    }
    
    public void menu_afin() {
        System.out.println("                                            ");
        System.out.println("************** UNIVERSIDAD AUTONOMA DE OCCIDENTE **************");
        System.out.println("          Algoritmo de Sustitucion monoalfabetica AFIN"         );
        System.out.println("                                            ");
        System.out.println("                                            ");        
        System.out.println("Sintaxis:");
        System.out.println("java -jar veraf.jar -af <opcion> -texto <ArchivoEntrada> -txtclave <ArchivoClave>");
        System.out.println("                                            ");
        System.out.println("<opcion> :  -c para cifrar el archivo <ArchivoEntrada> ");
        System.out.println("            -d para descifrar el archivo <ArchivoEntrada>");
        System.out.println("                                            ");
        System.out.println("<ArchivoEntrada>: nombre del archivo de entrada");
        System.out.println("<ArchivoClave>  : nombre del archivo que contiene la clave");
        System.out.println("    ");
        System.out.println("Si <opcion> es -c, el archivo de salida es <ArchivoEntrada>,");
        System.out.println("que cambia a la extension .cif");
        System.out.println(" ");
        System.out.println("Si <opcion> es -d, el archivo de salida es <ArchivoEntrada>,");
        System.out.println("que cambia a la extension .txt");
        System.out.println(" ");
        System.out.println("El archivo clave que contiene los valores de a=14, b=3 y tamaño del alfabeto = 37");
        System.out.println("deben de estar separados por comas y sin espacios, por ejemplo: 14,3,37");
        System.out.println("");
        System.out.println("El resultado del cifrado proyectara el hash del texto en claro.");
        System.out.println("El resultado del descifrado proyectara el hash despues de decifrarse,");
        System.out.println("ambos hash deben ser iguales.");
        System.out.println("");
        System.out.println("Ejemplo:");
        System.out.println("");
        System.out.println("Cifrar:    java -jar veraf.jar -af -c -texto quijote.txt -txtclave clavegrupo.txt");
        System.out.println("Descifrar: java -jar veraf.jar -af -d -texto quijote.cif -txtclave clavegrupo.txt");
        System.out.println("                                            ");
        System.out.println("Elaborado por:  Wilmer Coral:       jwcl61@hotmail.com");
        System.out.println("                Osvaldo Jimenez:    shukko55@hotmail.com");     
    }
    
    public void menu_vernam() {
        System.out.println("                                            ");
        System.out.println("************** UNIVERSIDAD AUTONOMA DE OCCIDENTE **************");
        System.out.println("          Algoritmo de Sustitucion polialfabetica VERNAM"         );
        System.out.println("                                            ");
        System.out.println("                                            ");        
        System.out.println("Sintaxis:");
        System.out.println("java -jar veraf.jar -ve <opcion> -texto <ArchivoEntrada> -txtclave <ArchivoClave>");
        System.out.println("                                            ");
        System.out.println("<opcion> :  -c para cifrar el archivo <ArchivoEntrada> ");
        System.out.println("            -d para descifrar el archivo <ArchivoEntrada>");
        System.out.println("                                            ");
        System.out.println("<ArchivoEntrada>: nombre del archivo de entrada");
        System.out.println("<ArchivoClave>  : nombre del archivo que contiene la clave");
        System.out.println("    ");
        System.out.println("Si <opcion> es -c, el archivo de salida es <ArchivoEntrada>,");
        System.out.println("que cambia a la extension .cif");
        System.out.println(" ");
        System.out.println("Si <opcion> es -d, el archivo de salida es <ArchivoEntrada>,");
        System.out.println("que cambia a la extension .txt");
        System.out.println(" ");
        System.out.println("El archivo clave contiene la clave con la cual se va cifrar el texto claro,");
        System.out.println("se debe ingresar una clave de un byte, por Ejemplo: R");
        System.out.println("");
        System.out.println("El resultado del cifrado proyectara el hash del texto en claro.");
        System.out.println("El resultado del descifrado proyectara el hash despues de decifrarse,");
        System.out.println("ambos hash deben ser iguales.");
        System.out.println("");
        System.out.println("Ejemplo:");
        System.out.println("");
        System.out.println("Cifrar:    java -jar veraf.jar -ve -c -texto quijote.txt -txtclave clavegrupo.txt");
        System.out.println("Descifrar: java -jar veraf.jar -ve -d -texto quijote.cif -txtclave clavegrupo.txt");
        System.out.println("                                            ");
        System.out.println("Elaborado por:  Wilmer Coral:       jwcl61@hotmail.com");
        System.out.println("                Osvaldo Jimenez:    shukko55@hotmail.com");     
    }
}
