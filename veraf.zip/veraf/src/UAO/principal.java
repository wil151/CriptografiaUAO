package UAO;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class principal {

    public static int inv = 0;
    public static int MCD = 0;

    /* procedimiento que calcula el valor del maximo com�n divisor
	    * de a y b siguiendo el algoritmo de euclides extendido,
	    * devolviendo en un arreglo la siguiente estructura [d,x,y]
	    * donde:
	    *    mcd(a,b) = d = a*x + b*y
	    **/
    public static int[] euclidesExtendido(int a, int b) {
        int[] resp = new int[3];
        int x = 0, y = 0, d = 0;

        if (b == 0) {
            resp[0] = a;
            resp[1] = 1;
            resp[2] = 0;
        } else {
            int x2 = 1, x1 = 0, y2 = 0, y1 = 1;
            int q = 0, r = 0;

            while (b > 0) {
                q = (a / b);
                r = a - q * b;
                x = x2 - q * x1;
                y = y2 - q * y1;
                a = b;
                b = r;
                x2 = x1;
                x1 = x;
                y2 = y1;
                y1 = y;
            }

            resp[0] = a;
            resp[1] = x2;
            resp[2] = y2;
        }
        return resp;
    }

    /*
	     * Procedimiento que calcula el m�dulo inverso: (a^-1)( mod n)
	     * pero devuelve false, si no existe el inverso o true en caso
	     * contrario.
	     * Si el valor del inverso es calculado, entonces es almacenado
	     * en la variable global inv
	     **/
    public static boolean moduloInverso(int a, int n) {
        int[] resp = new int[3];

        // System.out.println("a: "+ a +" n: "+ n);
        resp = euclidesExtendido(a, n);

        if (resp[0] > 1) {
            MCD = resp[0];
            return false;
        } else {
            MCD = resp[0];
            if (resp[1] < 0) //inv = resp[1]+n;
            {
                inv = resp[2];
            } else //inv = resp[1];
            {
                inv = resp[2] + a;
            }
            return true;
        }
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        String[] resp = new String[3];

        int Const_Multi = 0;
        int Const_Desplaz = 0;
        int Tam_alfabeto = 0;

        menu men = new menu();

        if (args.length == 0) { //Valida que se ingrese 1 argumento
            men.menu_principal();
        } else {
            if (args[0].equals("-af") && (args.length == 1)) {
                men.menu_afin();
            }
            if (args[0].equals("-ve") && (args.length == 1)) {
                men.menu_vernam();
            }

            //Valida que se ingresen los 6 argumentos
            if (args.length == 6) {

                File ArcMensaje = new File(args[3]);
                File ArcClave = new File(args[5]);

                if (ArcMensaje.exists() && ArcClave.exists()) {//Valido la existencia del archivo quijote y claves

                    long startTime = System.currentTimeMillis();
                    if (args[0].equals("-af")
                            && args[1].equals("-c")
                            && args[2].equals("-texto")
                            && args[3].equals(ArcMensaje.toString())
                            && args[4].equals("-txtclave")
                            && args[5].equals(ArcClave.toString())) {

                        grupoclave key = new grupoclave();
                        String Const[] = key.leergrupoclave(ArcClave.toString());

                        Const_Multi = Integer.parseInt(Const[0]);
                        Const_Desplaz = Integer.parseInt(Const[1]);
                        Tam_alfabeto = Integer.parseInt(Const[2]);

                        if (moduloInverso(Tam_alfabeto, Const_Multi)) {
                            System.out.println("");
                            //System.out.println("El Inverso multiplicativo es: " + inv);
                            //System.out.println("El m�ximo Com�n Divisor es: " + MCD);

                            LeerMensaje Read = new LeerMensaje();
                            String TextoClaro = Read.LeerMensajeISO(ArcMensaje.toString());     //Variable que contiene el texto en claro

                            Hash_MD5 Hash = new Hash_MD5();
                            String H1 = Hash.getCodigoHash(ArcMensaje.toString()); //Variable que contiene el hash del texto en claro

                            System.out.println("El Hash del archivo " + ArcMensaje.toString() + " es: " + H1);
                            System.out.println("");

                            String NombreFichero;
                            NombreFichero = ArcMensaje.toString();

                            Enc_Desc Encr = new Enc_Desc(Const_Multi, Const_Desplaz, inv, Tam_alfabeto, TextoClaro);  //a, b
                            Encr.EncriptarAfin(NombreFichero);

                            System.out.println("El tiempo de ejecucion del aplicativo es de: " + (System.currentTimeMillis() - startTime) + " ms.");
                        } else {
                            System.out.println(" ");
                            System.out.println("No tiene inverso multiplicativo.");
                        }

                    }
                }

                if (ArcMensaje.exists() && ArcClave.exists()) {//Valido la existencia del archivo quijote y claves

                    long startTime = System.currentTimeMillis();
                    if (args[0].equals("-af")
                            && args[1].equals("-d")
                            && args[2].equals("-texto")
                            && args[3].equals(ArcMensaje.toString())
                            && args[4].equals("-txtclave")
                            && args[5].equals(ArcClave.toString())) {

                        grupoclave key = new grupoclave();
                        String Const[] = key.leergrupoclave(ArcClave.toString());

                        Const_Multi = Integer.parseInt(Const[0]);
                        Const_Desplaz = Integer.parseInt(Const[1]);
                        Tam_alfabeto = Integer.parseInt(Const[2]);

                        if (moduloInverso(Tam_alfabeto, Const_Multi)) {
                            System.out.println("");
                            //System.out.println("El Inverso multiplicativo es: " + inv);
                            //System.out.println("El m�ximo Com�n Divisor es: " + MCD);

                            LeerMensaje Read = new LeerMensaje();
                            String TextoCifrado = Read.LeerMensajeISO(ArcMensaje.toString());     //Variable que contiene el texto en claro

                            String NombreFichero;
                            NombreFichero = ArcMensaje.toString();

                            Enc_Desc Desc = new Enc_Desc(Const_Multi, Const_Desplaz, inv, Tam_alfabeto, TextoCifrado);  //a, b
                            Desc.DesencriptarAfin(NombreFichero);

                            String rename = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));

                            NombreFichero = rename +"descifrado"+ ".txt";

                            Hash_MD5 Hash = new Hash_MD5();
                            String H1 = Hash.getCodigoHash(NombreFichero); //Variable que contiene el hash del texto en claro
                            System.out.println("");
                            System.out.println("El Hash del archivo " + NombreFichero + " es: " + H1);
                            System.out.println("El tiempo de ejecucion del aplicativo es de: " + (System.currentTimeMillis() - startTime) + " ms.");

                        } else {
                            System.out.println(" ");
                            System.out.println("No tiene inverso multiplicativo.");
                        }
                    }
                }

                if (ArcMensaje.exists() && ArcClave.exists()) {
                    if (args[0].equals("-ve")
                            && args[1].equals("-c")
                            && args[2].equals("-texto")
                            && args[3].equals(ArcMensaje.toString())
                            && args[4].equals("-txtclave")
                            && args[5].equals(ArcClave.toString())) {

                        long startTime = System.currentTimeMillis();
                        grupoclave key = new grupoclave();
                        String Const[] = key.leergrupoclave(ArcClave.toString());

                        String Clave = Const[0];

                        int ClaveBin = (int) Clave.charAt(0);

                        LeerMensaje Read = new LeerMensaje();
                        String TextoClaro = Read.LeerMensajeISO(ArcMensaje.toString());     //Variable que contiene el texto en claro

                        Hash_MD5 Hash = new Hash_MD5();
                        String H1 = Hash.getCodigoHash(ArcMensaje.toString()); //Variable que contiene el hash del texto en claro

                        System.out.println("El Hash del archivo " + ArcMensaje.toString() + " es: " + H1);
                        System.out.println("");

                        String NombreFichero;
                        NombreFichero = ArcMensaje.toString();

                        Enc_Desc Encr = new Enc_Desc(Const_Multi, Const_Desplaz, inv, Tam_alfabeto, TextoClaro);  //a, b
                        Encr.EncriptarVernam(NombreFichero, ClaveBin);
                        System.out.println("El tiempo de ejecucion del aplicativo es de: " + (System.currentTimeMillis() - startTime) + " ms.");
                    }
                }
                if (ArcMensaje.exists() && ArcClave.exists()) {
                    if (args[0].equals("-ve")
                            && args[1].equals("-d")
                            && args[2].equals("-texto")
                            && args[3].equals(ArcMensaje.toString())
                            && args[4].equals("-txtclave")
                            && args[5].equals(ArcClave.toString())) {

                        long startTime = System.currentTimeMillis();
                        grupoclave key = new grupoclave();
                        String Const[] = key.leergrupoclave(ArcClave.toString());

                        String Clave = Const[0];
                        //char c = Clave.charAt(0);

                        int ClaveBin = (int) Clave.charAt(0);
                        //    String ClaveBin = Integer.toBinaryString(c);

                        LeerMensaje Read = new LeerMensaje();
                        String TextoClaro = Read.LeerMensajeUTF8(ArcMensaje.toString());     //Variable que contiene el texto en claro

                        //  System.out.println(TextoClaro);
                        String NombreFichero;
                        NombreFichero = ArcMensaje.toString();

                        Enc_Desc Encr = new Enc_Desc(Const_Multi, Const_Desplaz, inv, Tam_alfabeto, TextoClaro);  //a, b
                        Encr.DesencriptarVernam(NombreFichero, ClaveBin);

                        String rename = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));
                        NombreFichero = rename + ".txt";

                        NombreFichero = rename +"descifrado"+ ".txt";
                        Hash_MD5 Hash = new Hash_MD5();
                        String H1 = Hash.getCodigoHash(NombreFichero); //Variable que contiene el hash del texto en claro

                        System.out.println("El Hash del archivo " + NombreFichero + " es: " + H1);
                        System.out.println("");

                        System.out.println("El tiempo de ejecucion del aplicativo es de: " + (System.currentTimeMillis() - startTime) + " ms.");

                    }
                }
            }
        }
    }
}

