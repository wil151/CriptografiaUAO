/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UAO;

import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 *
 * @author Samy
 */
public class grupoclave {

    public String[] leergrupoclave(String nombreFichero) {
        String[] resp = new String[3];

        FileReader fr = null;
        try {

            fr = new FileReader(nombreFichero);

            int caract = 0;
            int i = 0;
            char digit;
            String Cad;
            resp[0] = "";   //Se almacena el valor de a, (Constante de multiplicacion).
            resp[1] = "";   //Se almacena el valor de b, (Constante de desplazamiento).
            resp[2] = "";   //Se almacena el valor de n,(Tamaño del alfabeto),
            while (caract != -1) {
                caract = fr.read();
                if ((caract == 44) || (caract == -1)) {
                    i = i + 1;
                } else {
                    digit = (char) caract;
                    Cad = String.valueOf(digit);
                    resp[i] = resp[i] + Cad;
                }
            }

        } catch (FileNotFoundException e) {
            //Operaciones en caso de no encontrar el fichero
            System.out.println("Error: Fichero no encontrado1");
            //Mostrar el error producido por la excepci�n
            System.out.println(e.getMessage());
        } catch (Exception e) {
            //Operaciones en caso de error general
            System.out.println("Error de lectura del fichero");
            System.out.println(e.getMessage());
        } finally {
            //Operaciones que se har�n en cualquier caso. Si hay error o no.
            try {
                //Cerrar el fichero si se ha abierto
                if (fr != null) {
                    fr.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar el fichero");
                System.out.println(e.getMessage());
            }
        }
        return resp;
    }
}
