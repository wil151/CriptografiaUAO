/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UAO;

//import static LeerFichero.UTF8toISO;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

/**
 *
 * @author Samy
 */
public class LeerMensaje {

    public String LeerMensajeUTF8(String nombreFichero) {
        String Samantha1 = "";

        try {
            //Abrir el fichero indicado en la variable nombreFichero    
            String cadena;
            //FileReader f = new FileReader(nombreFichero);
            // BufferedReader b = new BufferedReader(f);

            //BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(nombreFichero), "ISO-8859-9"));
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(nombreFichero), "utf-8"));

            while ((cadena = in.readLine()) != null) {
                Samantha1 = cadena;
            }
            in.close();

        } catch (FileNotFoundException e) {
            //Operaciones en caso de no encontrar el fichero
            System.out.println("Error: Fichero no encontrado");
            //Mostrar el error producido por la excepción
            System.out.println(e.getMessage());
        } catch (Exception e) {
            //Operaciones en caso de error general
            System.out.println("Error de lectura del fichero");
            System.out.println(e.getMessage());
        }
        return Samantha1;
    }

    public String LeerMensajeISO(String nombreFichero) {
        String Samantha1 = "";

        try {
            //Abrir el fichero indicado en la variable nombreFichero    
            String cadena;
            //FileReader f = new FileReader(nombreFichero);
            // BufferedReader b = new BufferedReader(f);

            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(nombreFichero), "ISO-8859-9"));
            //BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(nombreFichero), "utf-8"));

            while ((cadena = in.readLine()) != null) {
                Samantha1 = cadena;
                //  System.out.println(cadena); 
                //System.out.println(cadena);

            }
            in.close();

        } catch (FileNotFoundException e) {
            //Operaciones en caso de no encontrar el fichero
            System.out.println("Error: Fichero no encontrado");
            //Mostrar el error producido por la excepción
            System.out.println(e.getMessage());
        } catch (Exception e) {
            //Operaciones en caso de error general
            System.out.println("Error de lectura del fichero");
            System.out.println(e.getMessage());
        }
        return Samantha1;
    }
}
