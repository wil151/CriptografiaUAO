/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UAO;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;

/**
 *
 * @author Samy
 */
public class Enc_Desc {

    private int a;
    private int b;
    private int inverso;
    private int tam_alfa;

    private String cadena;
    private String alfabeto[] = new String[37];
    private String CadenaEncriptada;
    private String CadenaDesencriptada;

    // fichero = new FileWriter("prueba.txt");
    public Enc_Desc(int a, int b, int inverso, int tam_alfa, String cadena) {
        this.a = a;
        this.b = b;
        this.inverso = inverso;
        this.tam_alfa = tam_alfa;
        this.cadena = cadena;
        this.alfabeto[0] = "A";
        this.alfabeto[1] = "B";
        this.alfabeto[2] = "C";
        this.alfabeto[3] = "D";
        this.alfabeto[4] = "E";
        this.alfabeto[5] = "F";
        this.alfabeto[6] = "G";
        this.alfabeto[7] = "H";
        this.alfabeto[8] = "I";
        this.alfabeto[9] = "J";
        this.alfabeto[10] = "K";
        this.alfabeto[11] = "L";
        this.alfabeto[12] = "M";
        this.alfabeto[13] = "N";
        this.alfabeto[14] = "Ñ";
        this.alfabeto[15] = "O";
        this.alfabeto[16] = "P";
        this.alfabeto[17] = "Q";
        this.alfabeto[18] = "R";
        this.alfabeto[19] = "S";
        this.alfabeto[20] = "T";
        this.alfabeto[21] = "U";
        this.alfabeto[22] = "V";
        this.alfabeto[23] = "W";
        this.alfabeto[24] = "X";
        this.alfabeto[25] = "Y";
        this.alfabeto[26] = "Z";

        this.alfabeto[27] = "Ü";
        this.alfabeto[28] = "«";
        this.alfabeto[29] = "Ï";
        this.alfabeto[30] = "]";
        this.alfabeto[31] = "À";
        this.alfabeto[32] = "3";
        this.alfabeto[33] = "Ù";

        this.alfabeto[34] = "_";
        this.alfabeto[35] = "[";
        this.alfabeto[36] = "%";

    }

    public String LimpiarEspacios(String cadenas) {
        String aux = "";
        //limpiando espacios en blanco
        for (int i = 0; i < cadenas.length(); i++) {
            if (cadenas.charAt(i) != ' ')//Mientras sea diferente de un espacio vamos concatenando caracter a caracter en una nueva cadena
            {
                aux = aux + cadenas.charAt(i);
            }
        }
        return aux;
    }

    public ArrayList< Integer> CadenaNumeros(String aux) {
        ArrayList< Integer> cadena_en_numeros = new ArrayList<>();

        for (int j = 0; j < aux.length(); j++) {

            for (int k = 0; k < alfabeto.length; k++) {
                if (alfabeto[k].charAt(0) == aux.charAt(j))//Comparando cada caracter de la cadena auxiliar con cada elemento del alfabeto y si corresponde a la letra estoy guardando su posicio
                {
                    cadena_en_numeros.add(k);
                }
            }
        }
        return cadena_en_numeros;
    }

    public String NumerosCadena_Esp(int num) {
        String letra = "";
        switch (num) {
            case 0:
                letra = "A";
                break;
            case 1:
                letra = "B";
                break;
            case 2:
                letra = "C";
                break;
            case 3:
                letra = "D";
                break;
            case 4:
                letra = "E";
                break;
            case 5:
                letra = "F";
                break;
            case 6:
                letra = "G";
                break;
            case 7:
                letra = "H";
                break;
            case 8:
                letra = "I";
                break;
            case 9:
                letra = "J";
                break;
            case 10:
                letra = "K";
                break;
            case 11:
                letra = "L";
                break;
            case 12:
                letra = "M";
                break;
            case 13:
                letra = "N";
                break;
            case 14:
                letra = "Ñ";
                break;
            case 15:
                letra = "O";
                break;
            case 16:
                letra = "P";
                break;
            case 17:
                letra = "Q";
                break;
            case 18:
                letra = "R";
                break;
            case 19:
                letra = "S";
                break;
            case 20:
                letra = "T";
                break;
            case 21:
                letra = "U";
                break;
            case 22:
                letra = "V";
                break;
            case 23:
                letra = "W";
                break;
            case 24:
                letra = "X";
                break;
            case 25:
                letra = "Y";
                break;
            case 26:
                letra = "Z";
                break;

            case 27:
                letra = "Ü";
                break;
            case 28:
                letra = "«";
                break;
            case 29:
                letra = "Ï";
                break;
            case 30:
                letra = "]";
                break;
            case 31:
                letra = "À";
                break;
            case 32:
                letra = "3";
                break;
            case 33:
                letra = "Ù";
                break;
            case 34:
                letra = "_";
                break;
            case 35:
                letra = "[";
                break;
            case 36:
                letra = "%";
                break;

        }
        return letra;
    }

    public void EncriptarAfin(String NombreFichero) throws IOException {
        ArrayList< Integer> cadena_en_numeros = new ArrayList<>();

        String aux;
        //LIMPIANDO ESPACIOS EN BLANCO
        //aux = LimpiarEspacios(cadena);

        aux = cadena;
        //Convirtiendo cadena auxiliar en numeros para luego proceder a su encripacion
        cadena_en_numeros = CadenaNumeros(aux);
        int C;

        FileWriter fichero = null;

        System.out.println("El nombre del archivo del texto en claro es: " + NombreFichero);
        String rename = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));

        fichero = new FileWriter(rename + ".cif");      //Se crea un nuevo archivo con nombre del archivo inicial pero con exensi�n .cif 
        System.out.println("El nombre del archivo cifrado es: " + rename + ".cif");

        Writer escribe = null;

        escribe = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(rename + ".cif"), "ISO-8859-9"));

        for (int m = 0; m < cadena_en_numeros.size(); m++) {
            C = (a * cadena_en_numeros.get(m) + b) % tam_alfa;
            String let = NumerosCadena_Esp(C);
            escribe.write(let);
        }
        escribe.close();        //Se cierra el archivo cifrado
    }

    public void DesencriptarAfin(String NombreFichero) throws IOException {
        ArrayList< Integer> cadena_en_numeros = new ArrayList<>();

        String aux;
        aux = cadena;
        //Convirtiendo cadena auxiliar en numeros para luego proceder a su encripacion
        cadena_en_numeros = CadenaNumeros(aux);
        int C;

        FileWriter fichero = null;
        PrintWriter pw = null;

        System.out.println("El nombre del archivo cifrado es: " + NombreFichero);
        String rename = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));
        String rencifra = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));

        // fichero = new FileWriter(rename + ".txt");      //Se crea un nuevo archivo con nombre del archivo inicial pero con exensi�n .cif 
        System.out.println("El nombre del archivo descifrado es: " + rencifra + "descifrado" + ".txt");

        Writer escribe = null;
        escribe = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(rencifra + "descifrado" + ".txt"), "ISO-8859-9"));
        // new FileOutputStream(rename + "cifrado" + ".txt"), "ISO-8859-9"));

        for (int m = 0; m < cadena_en_numeros.size(); m++) {
            C = (inverso * (cadena_en_numeros.get(m) - b)) % tam_alfa;
            if (C < 0) {
                C = C + tam_alfa;
            }
            String let = NumerosCadena_Esp(C);
            escribe.write(let);
        }
        escribe.close();        //Se cierra el archivo cifrado
    }

    public void EncriptarVernam(String NombreFichero, int ClaveBin) throws IOException {
        ArrayList< Integer> cadena_en_numeros = new ArrayList<>();

        String aux;

        aux = cadena;
        //Convirtiendo cadena auxiliar en numeros para luego proceder a su encripacion
        cadena_en_numeros = CadenaNumeros(aux);
        int C;

        FileWriter fichero = null;
        PrintWriter pw = null;

        System.out.println("El nombre del archivo del texto en claro es: " + NombreFichero);
        String rename = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));

        fichero = new FileWriter(rename + ".cif");      //Se crea un nuevo archivo con nombre del archivo inicial pero con exensi�n .cif 
        System.out.println("El nombre del archivo cifrado es: " + rename + ".cif");

        pw = new PrintWriter(fichero);

        Writer escribe = null;

        escribe = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(rename + ".cif"), "ISO-8859-9"));

        int XOR, Caracter;
        for (int m = 0; m < cadena_en_numeros.size(); m++) {

            C = cadena_en_numeros.get(m);
            String let = NumerosCadena_Esp(C);

            Caracter = (int) let.charAt(0);

            XOR = Caracter ^ ClaveBin;      //Realiza la operacion XOR
            String ClaveBi = Integer.toBinaryString(XOR);
            int result = Integer.parseInt(ClaveBi);
            String ochobits = String.format("%08d", result);
            escribe.write(ochobits);
        }
        escribe.close();        //Se cierra el archivo cifrado
    }

    public void DesencriptarVernam(String NombreFichero, int ClaveBin) throws IOException {

        String sCadena;
        sCadena = cadena;

        FileWriter fichero = null;
        PrintWriter pw = null;

        System.out.println("El nombre del archivo cifrado es: " + NombreFichero);
        String rename = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));
        String rencifra = NombreFichero.substring(0, NombreFichero.lastIndexOf("."));

        System.out.println("El nombre del archivo descifrado es: " + rencifra + "descifrado" + ".txt");
      
        Writer escribe = null;
        escribe = new BufferedWriter(new OutputStreamWriter(
                // new FileOutputStream(rename + ".txt"), "ISO-8859-9"));
                new FileOutputStream(rencifra + "descifrado" + ".txt"), "ISO-8859-9"));
        String sSubCadena;
        int InfCad = 0;
        int SupCad = 8;
        char caracter;

        int peso = 0;
        for (int m = 0; SupCad <= sCadena.length(); m++) {
            sSubCadena = sCadena.substring(InfCad, SupCad);
            InfCad = InfCad + 8;
            SupCad = SupCad + 8;

            peso = 0;
            if (sSubCadena.charAt(0) == '1') {
                peso = peso + 128;
            }
            if (sSubCadena.charAt(1) == '1') {
                peso = peso + 64;
            }
            if (sSubCadena.charAt(2) == '1') {
                peso = peso + 32;
            }
            if (sSubCadena.charAt(3) == '1') {
                peso = peso + 16;
            }
            if (sSubCadena.charAt(4) == '1') {
                peso = peso + 8;
            }
            if (sSubCadena.charAt(5) == '1') {
                peso = peso + 4;
            }
            if (sSubCadena.charAt(6) == '1') {
                peso = peso + 2;
            }
            if (sSubCadena.charAt(7) == '1') {
                peso = peso + 1;
            }

            caracter = (char) (peso ^ ClaveBin); //XOR entre la clave y el dato convertido a binario
            escribe.write(caracter);
        }
        escribe.close();
    }
}
