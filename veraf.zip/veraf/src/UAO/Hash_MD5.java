/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author Samy
 */
public class Hash_MD5 {

    public  String getCodigoHash(String path)
            throws NoSuchAlgorithmException, FileNotFoundException, IOException {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        File f = new File(path);
        InputStream is = new FileInputStream(f);
        byte[] buffer = new byte[(int) f.length()];
        int read = 0;
        while ((read = is.read(buffer)) > 0) {
            digest.update(buffer, 0, read);
        }
        byte[] md5sum = digest.digest();
        BigInteger bigInt = new BigInteger(1, md5sum);
        String output = bigInt.toString(16);
        is.close();
        return output;
    }

    public  boolean Comparar(String file, String hashCode)
            throws NoSuchAlgorithmException, FileNotFoundException, IOException {
        return hashCode.equals(getCodigoHash(file));
    }

    public  boolean comparar(String file1, String file2) throws NoSuchAlgorithmException, FileNotFoundException, IOException {
        return getCodigoHash(file1).equals(getCodigoHash(file2));
    }
}
